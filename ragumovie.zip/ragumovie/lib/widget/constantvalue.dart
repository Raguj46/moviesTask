class Constantsvlaue {
  static const String Authorization = "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJiMGI4YWI3YzU4MTY1YTg4YzBiYTU3NWU5ZjI0ODU2ZiIsInN1YiI6IjYzYmQ5Y2QwODEzODMxMDBiZDc1ZjU0ZSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.bgaf5AHy2ZP2tSjLE0pa5lyMNM1YkmRuvo0lZ-1drfw";
  static const String ContentType = "application/json;charset=utf-8";
}