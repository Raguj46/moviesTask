package com.example.ragumovie

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
